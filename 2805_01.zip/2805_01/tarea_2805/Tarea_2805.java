package tarea_2805;

import java.util.Scanner;

public class Tarea_2805 {
	public static void main(String[]args) {
		Scanner lector = new Scanner(System.in);
		
		System.out.println("De las siguientes 10 personas, ingrese sus edades");
		
		int[] edad= new int[10];
		int menor=0;
		
		for(int i=0;i<10;i++) {
			System.out.println("Edad de la persona "+(i+1));
			edad[i] = lector.nextInt();
			if (edad[i]<18) {
				menor+=1;
			}
		}
	System.out.println("Las edades de todos son: ");
	for(int i=0;i<10;i++){
		System.out.println("Edad de la persona "+(i+1)+" es: "+edad[i]);
			}
	System.out.println("Hay "+menor+" menores de edad y "+(10-menor)+" mayores de edad.");
	menor=0;
	
	}

}
